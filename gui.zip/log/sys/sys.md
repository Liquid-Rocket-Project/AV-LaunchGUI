This is the system log folder, where system actions are logged.
