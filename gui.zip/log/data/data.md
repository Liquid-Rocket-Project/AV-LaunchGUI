This is the data log folder, where sensor data is logged.
